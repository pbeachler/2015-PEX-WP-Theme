</div>
<!--Closing ContentFrame-->

<footer class="footer">
     <div id="footerwidget" class="widget-area" >
      <?php dynamic_sidebar( 'footer-1' ); ?>
     </div><!-- #tertiary .widget-area -->
</footer>
<?php wp_footer(); //Crucial footer hook! ?>

<!--Analytics-->

</body>
</html>